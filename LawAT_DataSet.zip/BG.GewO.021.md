# BG.GewO.021 — Gewerbeordnung (GewO)
**Typ:** Bundesgesetz  
**Kurztitel:** GewO  
**Langtitel:** Gewerbeordnung 1994 – GewO 1994  
**Gesamte Rechtsvorschrift in der Fassung vom:** 17.07.2025  
**Quelle:** https://ris.bka.gv.at/GeltendeFassung.wxe?Abfrage=Bundesnormen&Gesetzesnummer=10007517  
**Letzte Änderung im RIS:** BGBl. I Nr. 150/2024 (NR: GP XXVIII IA 3/A AB 7 S. 3. BR: AB 11609 S. 972.)  
**LawAT Permalink:** https://github.com/clairexen/LawAT/blob/main/files/BG.GewO.021.md  
*Mit RisEx für RisEn, RisEn-GPT, und LawAT von HTML zu MarkDown konvertiert. (Irrtümer und Fehler vorbehalten.)*

*Das ist die "AI-Friendly" multi-part Variante dieser Rechtsvorschrift mit kompakter Formatierung. Siehe [BG.GewO.md](BG.GewO.md) für die "Human-Friendly" single-page Variante dieser Norm mit hübscherer Formatierung.*

*(Fortsetzg. v. [BG.GewO.020](BG.GewO.020.md))*

## VII. Hauptstück

### § 374 GewO # Übergangsbestimmungen und Vollziehung

`§ 374 GewO.`  
§ 374 entfällt.

`END-OF-DATA-FILE` *(fortges. in [BG.GewO.022](BG.GewO.022.md))*
